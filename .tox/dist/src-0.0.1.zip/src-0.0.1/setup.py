from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="Its a basic MLOps package", 
    author="utkarsh-prakash", 
    packages=find_packages(),
    license="MIT"
)